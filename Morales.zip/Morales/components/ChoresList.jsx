import React from "react";

class ChoresList extends React.Component() {
    render() {
        return(
            <>
        <ul>
            <li> Clean Porch</li>  
            <li> Wash Car</li>  
            <li> Attend BCHAIN Class</li>  
            </ul>
        </>
        );
    }
}

export default ChoresList