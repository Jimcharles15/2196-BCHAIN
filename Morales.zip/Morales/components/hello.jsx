export default function Hello(){
    var message = "I think"
    return(
        <>
        <div>
            <h3>Hello World</h3>
            <h1>{message}</h1>
        </div>
        </>
    );
}