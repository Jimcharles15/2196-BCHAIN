import React from "react";

class BookList extends React.Component() {
    render() {
        return(
            <>
        <ul>
            <li> Hunger Games</li>  
            <li> The Tales of Enteng</li>  
            <li> How to Use a Power Meter</li>  
            </ul>
        </>
        );
    }
}

export default BookList