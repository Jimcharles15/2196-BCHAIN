import React from "react";

class MovieList extends React.Component() {
    render() {
        return(
            <>
        <ul>
            <li> Enteng Kabisote</li>  
            <li> Praybeyt Benjamin</li>  
            <li> Ogie and the Alcasids</li>  
            </ul>
        </>
        );
    }
}

export default MovieList